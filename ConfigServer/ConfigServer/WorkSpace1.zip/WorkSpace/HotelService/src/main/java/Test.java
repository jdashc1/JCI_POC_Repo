import jakarta.ws.rs.Produces;
import java.util.function.Consumer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Producer;

public class Test {

//  Consumer

}
